package com.gdx.cellular.input;

public enum MouseMode {
    SPAWN,
    BOID,
    EXPLOSION,
    HEAT,
    PARTICLE,
    PARTICALIZE,
    PHYSICSOBJ,
    RECTANGLE
}
