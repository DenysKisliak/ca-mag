package com.gdx.cellular.elements.solid;

import com.gdx.cellular.elements.Element;

public abstract class Solid extends Element {

    public Solid(int x, int y) {
        super(x, y);
    }
}
